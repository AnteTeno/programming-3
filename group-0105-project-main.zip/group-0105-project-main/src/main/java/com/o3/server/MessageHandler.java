package com.o3.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.AccessDeniedException;
import java.security.Principal;
import java.sql.SQLException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.stream.Collectors;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

public class MessageHandler implements HttpHandler {

    

    public MessageHandler() {
        
    }

/*
 * Handle method for handling requests made to server context: datarecord
 * @param exchange used for HTTP requests
 * @return nothing
 * @throws IOException
 */

    @Override
    @SuppressWarnings("UseSpecificCatch")
    public void handle(HttpExchange exchange) throws IOException {
        try {
            // Check that the user is authenticated
            String user = getUser(exchange);

            if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                checkContentType(exchange);
                handlePost(exchange, user);
            } else if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                checkContentType(exchange);
                handleGet(exchange);
            } else {
                sendResponse(exchange, 405, "Method Not Allowed");
            }

        } catch (AccessDeniedException e) {
            sendResponse(exchange, 403, "Forbidden: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            sendResponse(exchange, 415, "Unsupported Media Type: " + e.getMessage());
        } catch (JSONException e) {
            sendResponse(exchange, 400, "Bad Request: Invalid JSON");
        } catch (SQLException | IOException e) {
            System.err.println("SQLexception or IOexception"+ e.getMessage());
            sendResponse(exchange, 500, e.getMessage());
        } catch(IllegalAccessException e) {
            System.err.println("IllegalAccessexx");
            sendResponse(exchange, 500, "IllegalAccessException: "+e.getMessage());
        } catch(Exception e) {
            System.err.println("EXCEPTION "+e.getMessage());
            sendResponse(exchange, 500, e.getMessage());
        }
    }
  
    private void handlePost(HttpExchange exchange, String user) throws IOException, SQLException, IllegalAccessException, JSONException {
        String jsonString;

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8))) {
            jsonString = reader.lines().collect(Collectors.joining("\n"));
        }

        try {
            JSONObject jsonObject = new JSONObject(jsonString);


            String identifier = jsonObject.getString("recordIdentifier");
            String description = jsonObject.getString("recordDescription");
            String payload = jsonObject.getString("recordPayload");
            String rightAscension = jsonObject.getString("recordRightAscension");
            String declination = jsonObject.getString("recordDeclination");
            String recordOwner = MessageDatabase.getInstance().getRecordOwner(user);
            Long postingTime = getUTCTime();
            JSONArray observatory = jsonObject.optJSONArray("observatory", null);
            JSONArray weatherObservatory = null;
            if(observatory != null) {
                JSONObject observatorioObject = (JSONObject) observatory.get(0);
                if (observatorioObject != null && !checkObservatory(observatorioObject)) {
                    System.out.println("Json error while post handling");
                    throw new IllegalArgumentException("Observatory data is missing or invalid: " + observatory);
                }
                if(jsonObject.has("observatoryWeather")) {
                    @SuppressWarnings("null")
                    BigDecimal latitude = observatorioObject.optBigDecimal("latitude", null);
                    BigDecimal longitude = observatorioObject.optBigDecimal("longitude", null);
                    if(longitude != null && latitude != null) {
                        weatherObservatory = WeatherServiceHandler.getWeatherInformation(latitude, longitude);
                    }
                }
            }
            
            
            //Here we set the values into the database, all information except the recordOwner is found in the jsonObject given by the user
            //recordOwner is fetched from the database if not given we set the recordOwner to the username given by the user
           MessageDatabase.getInstance().addObservation(user, identifier, description, payload, rightAscension, declination, recordOwner, postingTime, observatory, weatherObservatory);

           sendResponse(exchange, 201, "Record added successfully");

        } catch (JSONException e) {
            sendResponse(exchange, 400, "JSONERROR: "+e.getMessage());
            System.err.println("JSON error while post handling"+e.getMessage());

        } catch (SQLException e) {
            System.err.println("SQL error while post handling"+e.getMessage());
            sendResponse(exchange, 500, "Database error:" +e.getMessage());
        } catch (IllegalArgumentException e) {
            System.err.println("illegalargexc error while post handling"+e.getMessage());
            sendResponse(exchange, 400, "IllegalAccessException: "+e.getMessage());
        } catch (IOException e) {
            System.err.println("IOexception error while post handling");
            sendResponse(exchange, 500, "Internal server errror: " +e.getMessage());
        }
    }



    private void handleGet(HttpExchange exchange) throws IOException, SQLException {
        JSONArray responseMessages = MessageDatabase.getInstance().getObservations();
        System.out.println(responseMessages.toString());
        // Send the response back to the client
        if(!responseMessages.isEmpty()) {
            sendResponse(exchange, 200, responseMessages.toString());
        } else {
            sendResponse(exchange, 404, "No observations found!");
        }
    }
    


    public String getUser(HttpExchange exchange) throws AccessDeniedException {
        Principal principal = exchange.getPrincipal();
        if (principal == null) {
            throw new AccessDeniedException("User is not authenticated!");
        }
    
        String username = principal.getName();
    
        // Fix for "warning:" prefix issue
        if (username.contains(":")) {
            username = username.split(":", 2)[1];  // Get only the actual username
        }
    
        return username;
    }
    

    private void checkContentType(HttpExchange exchange) {
        String contentType = exchange.getRequestHeaders().getFirst("Content-Type");
        if (contentType == null || !"application/json".equalsIgnoreCase(contentType)) {
            throw new IllegalArgumentException("Expected Content-Type: application/json");
        }
    }
    
    public void sendResponse(HttpExchange exchange, int statusCode, String responseMessage) throws IOException {
        byte[] responseBytes = responseMessage.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(statusCode, responseBytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(responseBytes);
            os.flush();
        }
    }

    

    private Long getUTCTime() {
        ZonedDateTime now = ZonedDateTime.now(ZoneId.of("UTC"));
        return now.toInstant().toEpochMilli();
    }

    private boolean checkObservatory(JSONObject object) {
        if(object != null) {
            object.getString("observatoryName");
            object.getBigDecimal("latitude");
            object.getBigDecimal("longitude");
            return true;
        } return false;
        
    }
    
  
    
}
