package com.o3.server;


import java.sql.SQLException;

import org.apache.commons.codec.digest.Crypt;


public class UserAuthenticator extends com.sun.net.httpserver.BasicAuthenticator{
    

    @SuppressWarnings("Convert2Diamond")
    public UserAuthenticator() {
        super("warning");
    }

    @Override
    public boolean checkCredentials(String username, String password) {
        try {
            // Debugging output

            // Fix username extraction issue
            if (username.contains(":")) {
                username = username.split(":", 2)[1];  // Get only the actual username
            }

            String storedPassword = MessageDatabase.getInstance().getPassword(username);
            if (storedPassword == null) {
                return false;
            }

            return comparePasswords(password, storedPassword);
        } catch (SQLException | IllegalAccessException e) {
            return false;
        }
    }

    public boolean addUser(String username, String password, String email, String nickname) throws SQLException {
        return MessageDatabase.getInstance().addUser(username, email, password, nickname);
    }

    public boolean comparePasswords(String password, String hashedPassword) {
        return hashedPassword.equals(Crypt.crypt(password, hashedPassword));
     }
}