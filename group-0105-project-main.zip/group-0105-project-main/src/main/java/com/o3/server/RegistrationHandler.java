package com.o3.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.stream.Collectors;

import org.json.JSONException;
import org.json.JSONObject;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

public class RegistrationHandler implements HttpHandler {
    private String response = "";
    private final UserAuthenticator authenticator;

    public RegistrationHandler(UserAuthenticator authenticator) {
        this.authenticator = authenticator;
    }

    @Override
    @SuppressWarnings("UseSpecificCatch")
    public void handle(HttpExchange exchange) throws IOException {
        Headers headers = exchange.getRequestHeaders();

        try {
            // Handle only POST requests
            if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                String contentType = headers.getFirst("Content-Type");

                if (contentType == null || !contentType.equalsIgnoreCase("application/json")) {
                    errorMessageSender(407, "Content-Type must be application/json", exchange);
                    return;
                }

                handlePOSTRequest(exchange);
            } else {
                errorMessageSender(405, "Unsupported HTTP method", exchange);
            }
        } catch (Exception e) {
            errorMessageSender(500, "Internal server error", exchange);
        }
    }

    private void handlePOSTRequest(HttpExchange exchange) throws IOException {
        try (InputStream stream = exchange.getRequestBody();
             BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {

            String newUser = reader.lines().collect(Collectors.joining("\n"));

            // Check if the user data is empty
            if (newUser == null || newUser.isEmpty()) {
                errorMessageSender(412, "Not enough credentials", exchange);
                return;
            }

            // Parse the incoming JSON
            JSONObject object = new JSONObject(newUser);

            // Validate the incoming JSON fields
            
            //Check that we are dealing with proper credentials
            checkProperCredentials(object);

            // Try adding the user
            boolean result = authenticator.addUser(object.getString("username"), object.getString("password"), object.getString("email"), object.getString("userNickname"));
            if (result) {
                successMessageSender(exchange);
            } else {
                errorMessageSender(405, "Username already exists", exchange);
            }
        } catch (JSONException e) {
            errorMessageSender(400, "Invalid JSON format", exchange);
        } catch(SQLException e) {
            errorMessageSender(500, e.getMessage(), exchange);
        } catch(IllegalArgumentException e) {
            errorMessageSender(400, e.getMessage(), exchange);
        }
    }

    private void errorMessageSender(int code, String message, HttpExchange exchange) throws IOException {
        response = message;
        exchange.sendResponseHeaders(code, response.getBytes(StandardCharsets.UTF_8).length);
        try (OutputStream stream = exchange.getResponseBody()) {
            stream.write(response.getBytes());
            stream.flush();
        }
    }

    private void successMessageSender(HttpExchange exchange) throws IOException {
        response = "Registration successful";
        byte[] responseBytes = response.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(200, responseBytes.length);
        try (OutputStream stream = exchange.getResponseBody()) {
            stream.write(responseBytes);
            stream.flush();
        }
    }

    private void checkProperCredentials(JSONObject object) {
        if (!object.has("username") || object.getString("username").isEmpty()) {
            throw new IllegalArgumentException("Username cannot be empty!");
        }
        if (!object.has("password") || object.getString("password").isEmpty()) {
            throw new IllegalArgumentException("Password cannot be empty!");
        }
        if (!object.has("email") || object.getString("email").isEmpty()) {
            throw new IllegalArgumentException("Email cannot be empty!");
        }
        if (!object.has("userNickname") || object.getString("userNickname").isEmpty()) {
            throw new IllegalArgumentException("UserNickname cannot be empty!");
        }
    }
    
}
