package com.o3.server;

import java.io.File;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;

import org.apache.commons.codec.digest.Crypt;
import org.json.JSONArray;
import org.json.JSONObject;



public final class MessageDatabase {

    //Variables
    private static MessageDatabase instance;
    private Connection connection;
    private boolean isNewDatabase;
    private final SecureRandom secureRandom = new SecureRandom();




    /**
    * Creates new database called database.db
    * @params null No parameters
    */
    private MessageDatabase() throws SQLException {
        open("database.db");
    }

    /**
     * Gets the database instance since we are using singleton
     * @return instance In
     */
    public static synchronized MessageDatabase getInstance() throws SQLException {
        if (instance == null) {
            instance = new MessageDatabase();
        }
        return instance;
    }


    /**
     * Opens SQLite database to local directory
     * @param dbName Database's name
     */
    public void  open(String dbName) throws SQLException {
        String dbUrl = "jdbc:sqlite:" + dbName;

        File dbFile = new File(dbName);
        isNewDatabase = !dbFile.exists() || dbFile.isDirectory();

        connection = DriverManager.getConnection(dbUrl);

        if(isNewDatabase) {
            initializeDB();
        }
    }


    /**
     * Initializes database with tables userTable and observationsTable
     * @param Null No parameters
      */
    private void initializeDB() throws SQLException{
        String userTable = "CREATE TABLE IF NOT EXISTS users ("+
                                "username TEXT NOT NULL PRIMARY KEY, "+
                                "email TEXT NOT NULL,"+
                                "password TEXT NOT NULL,"+
                                "userNickname TEXT NOT NULL"+
                            ")";
        String observationsTable = "CREATE TABLE IF NOT EXISTS observations ("+
                            "username TEXT NOT NULL,"+
                            "recordIdentifier TEXT NOT NULL,"+
                            "recordDescription TEXT NOT NULL,"+
                            "recordPayload TEXT NOT NULL,"+
                            "recordRightAscension TEXT NOT NULL,"+
                            "recordDeclination TEXT NOT NULL,"+
                            "recordOwner TEXT NOT NULL,"+
                            "recordTimeReceived INTEGER NOT NULL,"+
                            "observatory TEXT,"+ 
                            "observatoryWeather TEXT,"+
                            "FOREIGN KEY(username) REFERENCES users(username) ON DELETE CASCADE"+
                        ")";
                        

        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate(userTable);
            statement.executeUpdate(observationsTable);
        }

        String username = "u";
        String password = "p";
        String email = "kakka@pissmail.com";
        String nickname = "bossman";
        if (!isUser(username)) {
            addUser(username, email, password, nickname);
        }
    }


    /**
     * Closes database
     * @param Null No parameters
     */
    public void close() throws SQLException {
        if(connection == null) {
            return;
        }

        
        connection.close();
        connection = null;
    }




    /**
     * Checks if given username is already an registered user in the database
     * @param username The user that is under investigation
     * @return True If user is in the database
     * @return False If user is NOT in the database
     */
    private boolean isUser(String username) throws SQLException {
        

        String command = "SELECT COUNT(*) FROM users WHERE username = ?";

        try (PreparedStatement statement = connection.prepareStatement(command)) {
            statement.setString(1, username);
            try (ResultSet results = statement.executeQuery()) {
                if (results.next()) {
                    int count = results.getInt(1);
                    return count > 0;
                } else {
                    return false;
                }
            }
        }
    }


    public boolean addUser(String username, String email, String password, String nickname) throws SQLException {
        if(isUser(username)) {
            return false;
        }

        String command = "INSERT INTO users VALUES(?, ?, ?, ?)";

        byte bytes[] = new byte[13];
        secureRandom.nextBytes(bytes);
        String salt = bytesToString(bytes);

        String hashedPassword = Crypt.crypt(password, salt);
        

        try(PreparedStatement statement = connection.prepareStatement(command)) {
            statement.setString(1, username);
            statement.setString(2, email);
            statement.setString(3, hashedPassword);
            statement.setString(4, nickname);


            statement.executeUpdate();
            return true;
        }
    }


    public String getPassword(String username) throws SQLException, IllegalAccessException {

            

            // Set the command
            String command = "SELECT password FROM users WHERE username = ?";

            // Get the given user from users table
            try (PreparedStatement statement = connection.prepareStatement(command)) {
                statement.setString(1, username);
                try (ResultSet user = statement.executeQuery()) {
                    
                    // Does data of the user exist
                    if (user.next()) {
                        String passwordStr = user.getString("password");
                        return passwordStr;
                    }
                    // User is not found from users table
                    else {
                        throw new IllegalArgumentException("User not found\n");
                    }
                }
            }
        }

        public String getRecordOwner(String username) throws SQLException {
            
        
            String command = "SELECT userNickname FROM users WHERE username = ?";
            
            try (PreparedStatement statement = connection.prepareStatement(command)) {
                statement.setString(1, username);
                try (ResultSet user = statement.executeQuery()) {
        
                    if (user.next()) {
                        String nickname = user.getString("userNickname");
                        return nickname;
                    } else {
                        throw new IllegalArgumentException("Nickname not found: ");
                    }
                }   
            }
        }
        


        public void addObservation(String username, String recordIdentifier, String recordDescription,
            String recordPayload, String recordRightAscension, String recordDeclination, String recordOwner, Long recordTimeReceived, JSONArray observatory, JSONArray weatherObservatory) throws SQLException {            
            

            String command = "INSERT INTO observations VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            try(PreparedStatement statement = connection.prepareStatement(command)) {
                statement.setString(1, username);
                statement.setString(2, recordIdentifier);
                statement.setString(3, recordDescription);
                statement.setString(4, recordPayload);
                statement.setString(5, recordRightAscension);
                statement.setString(6, recordDeclination);
                statement.setString(7, recordOwner);
                statement.setLong(8, recordTimeReceived);



                if (observatory != null && !observatory.isEmpty()) {
                    statement.setString(9, observatory.toString());
                    if(weatherObservatory != null) {
                        statement.setString(10, weatherObservatory.toString());
                    } else {
                        statement.setNull(10, java.sql.Types.VARCHAR);
                    }
                } else {
                    statement.setNull(9, java.sql.Types.VARCHAR); // Store NULL if not provided
                    statement.setNull(10, java.sql.Types.VARCHAR);
                }

                
                
                System.out.println("[DEBUG] Inserting observation into database for user: " + username);
                statement.executeUpdate();
            }
        }


    public JSONArray getObservations() throws SQLException {
        
        String command = "SELECT * FROM observations";

        try(PreparedStatement statement = connection.prepareStatement(command)) { 
            try (ResultSet results = statement.executeQuery()) {

                JSONArray observations = new JSONArray();

                while(results.next()) {
                    String recordIdentifier = results.getString("recordIdentifier");
                    String recordDescription = results.getString("recordDescription");
                    String recordPayload = results.getString("recordPayload");
                    String recordRightAscension = results.getString("recordRightAscension");
                    String recordDeclination = results.getString("recordDeclination");
                    String recordOwner = results.getString("recordOwner");
                    Long recordTimeReceivedAsLong = results.getLong("recordTimeReceived");
                    String recordTimeReceived = utcTimeToString(recordTimeReceivedAsLong);
                    
                    JSONObject observation = new JSONObject();
                    observation.put("recordIdentifier", recordIdentifier);
                    observation.put("recordDescription", recordDescription);
                    observation.put("recordPayload", recordPayload);
                    observation.put("recordRightAscension", recordRightAscension);
                    observation.put("recordDeclination", recordDeclination);
                    observation.put("recordOwner", recordOwner);
                    observation.put("recordTimeReceived", recordTimeReceived);
                    


                    String observatory = results.getString("observatory");
                    String weatherObservatory = results.getString("observatoryWeather");
                    if (observatory != null && !observatory.isEmpty()) {
                        JSONArray jsonArray = new JSONArray(observatory);
                        observation.put("observatory", jsonArray);
                        if(weatherObservatory != null && !weatherObservatory.isEmpty()) {
                            JSONArray weatherArray = new JSONArray(weatherObservatory);
                            observation.put("observatoryWeather", weatherArray);
                        }
                    }

                    observations.put(observation);
                }



                if (observations.isEmpty()) {
                    throw new SQLException("No observations found ");
                }
                return observations;
            }
        }
    }

    private String utcTimeToString(Long time) {
        ZonedDateTime zonedDateTime = Instant.ofEpochMilli(time).atZone(ZoneId.of("UTC"));

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSX");

        return zonedDateTime.format(formatter);
    }


    public JSONArray searchObservations(String nickname, Long before, Long after, String identification) throws SQLException {
        JSONArray observations = new JSONArray();
        StringBuilder query = new StringBuilder("SELECT * FROM observations WHERE 1=1");
    
        if (nickname != null) query.append(" AND recordOwner = ?");
        if (before != null) query.append(" AND recordTimeReceived < ?");
        if (after != null) query.append(" AND recordTimeReceived > ?");
        if (identification != null) query.append(" AND recordIdentifier = ?");
    

        System.out.println(query);
        try (PreparedStatement stmt = this.connection.prepareStatement(query.toString())) {
            int index = 1;
            if (nickname != null) {
                stmt.setString(index++, nickname);
            }
            if (before != null) {
                stmt.setLong(index++, before);
            }
            if (after != null) {
                stmt.setLong(index++, after);
            }
            if (identification != null) {
                stmt.setString(index++, identification);
            }
    
            
    
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                JSONObject observation = new JSONObject();
                observation.put("recordIdentifier", rs.getString("recordIdentifier"));
                observation.put("recordDescription", rs.getString("recordDescription"));
                observation.put("recordPayload", rs.getString("recordPayload"));
                observation.put("recordRightAscension", rs.getString("recordRightAscension"));
                observation.put("recordDeclination", rs.getString("recordDeclination"));
                observation.put("recordOwner", rs.getString("recordOwner"));
                observation.put("recordTimeReceived", utcTimeToString(rs.getLong("recordTimeReceived")));
    
                String observatory = rs.getString("observatory");
                if (observatory != null && !observatory.isEmpty()) {
                    observation.put("observatory", new JSONArray(observatory));
                }
    
                observations.put(observation);
            }
        }
    
        return observations;
    }


   
    
    


    /* --------------------------------
        * --------------------------------
        * DATABASE SECURITY IMPLEMENTATION
        * --------------------------------
        * --------------------------------
        */

        public String bytesToString(byte bytes[]) {
            String saltBytes = new String(Base64.getEncoder().encode(bytes));
            String salt = "$6$" + saltBytes;
            salt = salt.replace("+", "a");

            return salt;
        }

        



}


