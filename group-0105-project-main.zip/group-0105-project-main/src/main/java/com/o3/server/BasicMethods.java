package com.o3.server;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.AccessDeniedException;
import java.security.Principal;

import com.sun.net.httpserver.HttpExchange;

public class BasicMethods {

    public static String getUser(HttpExchange exchange) throws AccessDeniedException {
        Principal principal = exchange.getPrincipal();
        if (principal == null) {
            throw new AccessDeniedException("User is not authenticated!");
        }
    
        String username = principal.getName();
    
        // Fix for "warning:" prefix issue
        if (username.contains(":")) {
            username = username.split(":", 2)[1];  // Get only the actual username
        }
    
        return username;
    }

    public static void checkContentType(HttpExchange exchange) {
        String contentType = exchange.getRequestHeaders().getFirst("Content-Type");
        if (contentType == null || !"application/json".equalsIgnoreCase(contentType)) {
            throw new IllegalArgumentException("Expected Content-Type: application/json");
        }
    }


    public static void sendResponse(HttpExchange exchange, int statusCode, String responseMessage) throws IOException {
        byte[] responseBytes = responseMessage.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(statusCode, responseBytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(responseBytes);
            os.flush();
        }
    }

    
}
