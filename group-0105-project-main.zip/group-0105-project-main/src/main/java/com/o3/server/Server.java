package com.o3.server;


import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.TrustManagerFactory;

import com.sun.net.httpserver.HttpContext;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpsConfigurator;
import com.sun.net.httpserver.HttpsParameters;
import com.sun.net.httpserver.HttpsServer;


public class Server implements HttpHandler {

	//Variables
	List<String> inputArray = new CopyOnWriteArrayList<>();

    private Server() {
		
    }
	

    @Override
    public void handle(HttpExchange t) throws IOException {
		System.out.println("Request handled in thread " + Thread.currentThread().threadId());


		if(t.getRequestMethod().equalsIgnoreCase("POST")) {
			handlePOSTRequest(t);

		} else if(t.getRequestMethod().equalsIgnoreCase("GET")) {
			handleGETRequest(t);

		} else {
			String response = "Not supported";
			t.sendResponseHeaders(400, response.length());
                    try (OutputStream outputStream = t.getResponseBody()) {
                        outputStream.write(response.getBytes());
                        outputStream.flush();
                    }

		}

    

    }


	private void handlePOSTRequest(HttpExchange exchange) throws IOException{
            try (InputStream stream = exchange.getRequestBody()) {
                String text = new BufferedReader(new InputStreamReader(stream,
                                StandardCharsets.UTF_8)).lines().collect(Collectors.joining("\n"));
                
                inputArray.add(text);
            }
		exchange.sendResponseHeaders(200, -1);
	}

	private void handleGETRequest(HttpExchange exchange) throws IOException {
		String responseString = "";
            for (String inputArray1 : inputArray) {
				if(inputArray1 != null) {
                responseString += inputArray1;
				}
            }
		
		byte[] bytes = responseString.getBytes(StandardCharsets.UTF_8);

		exchange.sendResponseHeaders(200, bytes.length);

            try (OutputStream outputStream = exchange.getResponseBody()) {
                outputStream.write(responseString.getBytes());
                
                outputStream.flush();
            }
		
	}

	

	private static SSLContext myServerSSLContext(String path, String password) throws Exception {
		char[] passphrase = password.toCharArray();
		KeyStore ks = KeyStore.getInstance("JKS");
		ks.load(new FileInputStream(path), passphrase);

		KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
		kmf.init(ks, passphrase);

		TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
		tmf.init(ks);

		SSLContext ssl = SSLContext.getInstance("TLS");
		ssl.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

		return ssl;
	}


	private static void createContext(HttpsServer server, String path, HttpHandler handler, UserAuthenticator authenticator) {
        HttpContext context = server.createContext(path, handler);
        context.setAuthenticator(authenticator);
        
    } 
	



    public static void main(String[] args) {
        try {
            if (args.length < 2) {
                return;
            }

            // Luo HTTPS-palvelin porttiin 8001
            HttpsServer server = HttpsServer.create(new InetSocketAddress(8001), 0);
            SSLContext sslContext = myServerSSLContext(args[0], args[1]);

            server.setHttpsConfigurator(new HttpsConfigurator(sslContext) {
                @Override
                public void configure(HttpsParameters params) {
                    SSLContext c = getSSLContext();
                    SSLParameters sslparams = c.getDefaultSSLParameters();
                    params.setSSLParameters(sslparams);
                }
            });

            UserAuthenticator authenticator = new UserAuthenticator();

            // Kutsutaan metodia joka luo kontekstit yksi kerrallaan
            createContext(server, "/help", new Server(), null);
            createContext(server, "/datarecord", new MessageHandler(), authenticator);
            createContext(server, "/registration", new RegistrationHandler(authenticator), null);
            createContext(server, "/search", new SearchHandler(), authenticator);
            createContext(server, "/datarecord/aidesc", new AiDesc(), authenticator);
            
            server.setExecutor(Executors.newCachedThreadPool());
			System.out.println("Server is on!");
            server.start();

        } catch (FileNotFoundException e) {
            System.err.println("Keystore file not found! Make sure the file path is correct.");
        } catch (IOException e) {
            System.err.println("I/O Exception occurred. Check port availability and permissions.");
        } catch (Exception e) {
            System.err.println("An unexpected error occurred: " + e.getMessage());
        }
    }


	
	

} 

