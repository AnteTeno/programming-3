package com.o3.server;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.AccessDeniedException;
import java.security.Principal;
import java.sql.SQLException;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

import org.json.JSONArray;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

public class SearchHandler implements HttpHandler {

    public SearchHandler() {
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {

        try {
            if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                handleGETRequest(exchange);
            } else {
                throw new NoSuchMethodException("Bad request during handling");
            }
        } catch (NoSuchMethodException e) {
            sendJsonResponse(exchange, 405, new JSONArray());
        } catch (SQLException e) {
            sendJsonResponse(exchange, 500, new JSONArray());
        } catch (IOException e) {
            sendJsonResponse(exchange, 500, new JSONArray());
        } catch (Exception e) {
            sendJsonResponse(exchange, 500, new JSONArray());
        }
    }

    @SuppressWarnings("CallToPrintStackTrace")
    public void handleGETRequest(HttpExchange exchange) throws AccessDeniedException, SQLException, IOException {
        String query = exchange.getRequestURI().getQuery();


        

        String nickname = getQueryParam(query, "nickname");
        String beforeString = getQueryParam(query, "before");
        String afterString = getQueryParam(query, "after");
        String identification = getQueryParam(query, "identification");

        System.out.println(beforeString + " "+ afterString);
    
        if (nickname == null && beforeString == null && afterString == null && identification == null) {
            System.out.println("All params null");
            sendJsonResponse(exchange, 400, new JSONArray()); // Return 400 Bad Request
            return;
        }

        
        Long before = null;
        Long after = null;
        try {
            before = timeToLong(beforeString);
            System.out.println("Converted startDate: " + before);
        } catch (Exception e) {
            System.out.println("Exception in timeToLong(startDateString): " + e.getMessage());
            e.printStackTrace();
        }

        try {
            after = timeToLong(afterString);
            System.out.println("Converted endDate: " + after);
        } catch (Exception e) {
            System.out.println("Exception in timeToLong(endDateString): " + e.getMessage());
            e.printStackTrace();
        }


        JSONArray results = MessageDatabase.getInstance().searchObservations(nickname, before, after, identification);
        sendJsonResponse(exchange, 200, results);
    }

    
    public Long timeToLong(String dateString) {
        if (dateString == null) {
            return null;
        }
        
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXXX");
            OffsetDateTime dateTime = OffsetDateTime.parse(dateString, formatter);
            return dateTime.toInstant().toEpochMilli(); 
        } catch (Exception e) {
            return null;
        }
    }

    private String getQueryParam(String query, String param) {
        if (query == null || query.isEmpty()) return null;
        try {
            for (String pair : query.split("&")) {
                String[] keyValue = pair.split("=", 2);
                if (keyValue.length == 2 && keyValue[0].equals(param)) {
                    String value = keyValue[1];
                    return value.isEmpty() ? null : value; 
                }
            }
        } catch (Exception e) {
            System.out.println("Error parsing query parameter: " + param);
        }
        return null;
    }

    public void sendJsonResponse(HttpExchange exchange, int statusCode, JSONArray data) throws IOException {
        byte[] responseBytes = data.toString().getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        exchange.sendResponseHeaders(statusCode, responseBytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(responseBytes);
            os.flush();
        }
    }

    public String getUser(HttpExchange exchange) throws AccessDeniedException {
        Principal principal = exchange.getPrincipal();
        if (principal == null) {
            throw new AccessDeniedException("User is not authenticated!");
        }

        String username = principal.getName();

        // Fix for "warning:" prefix issue
        if (username.contains(":")) {
            username = username.split(":", 2)[1]; // Get only the actual username
        }

        return username;
    }
}