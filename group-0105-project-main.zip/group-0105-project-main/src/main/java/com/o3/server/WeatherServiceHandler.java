package com.o3.server;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.MissingFormatArgumentException;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.XML;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class WeatherServiceHandler {


    private static final String url = "http://localhost:4001/wfs";

    @SuppressWarnings("null")
    public static JSONArray getWeatherInformation(BigDecimal latitude, BigDecimal longitude) throws IOException, MissingFormatArgumentException {
        OkHttpClient client = new OkHttpClient();


        Request request = new Request.Builder()
            .url(url+"?latlon="+latitude.toString()+","+longitude.toString()+"&parameters=temperatureInKelvins,cloudinessPercentance,bagroundLightVolume")
            .build();

            System.out.println(url+"?latlon="+latitude.toString()+","+longitude.toString()+"&parameters=temperatureInKelvins,cloudinessPercentance,bagroundLightVolume");
        try(Response response = client.newCall(request).execute()) {
            if(response.isSuccessful() && response.body() != null) {
                String xmlString = response.body().string();

                //Cast xml to JSONObject
                JSONObject weatherInformation = XML.toJSONObject(xmlString);
                System.out.println(weatherInformation.toString());
                return getNecessaryInformation(weatherInformation);
            } else {
                throw new MissingFormatArgumentException("Failed to return weatherInformation in getWeatherInformation");
            }
            
        } 
    }

    private static JSONArray getNecessaryInformation(JSONObject data) {
        JSONObject returnObject = new JSONObject();
        JSONArray wfsMember = data.getJSONObject("wfs:FeatureCollection").getJSONArray("wfs:member");

        for(int i = 0; i < wfsMember.length(); i++) {

            JSONObject information = wfsMember.getJSONObject(i).getJSONObject("BsWfs:BsWfsElement");
            String paramName = information.getString("BsWfs:ParameterName");

            switch (paramName) {
                case "temperatureInKelvins" -> returnObject.put("temperatureInKelvins", information.getBigDecimal("BsWfs:ParameterValue"));
                case "cloudinessPercentance" -> returnObject.put("cloudinessPercentage", information.getBigDecimal("BsWfs:ParameterValue"));
                case "bagroundLightVolume" -> returnObject.put("backgroundLightVolume", information.getBigDecimal("BsWfs:ParameterValue"));
                default -> throw new AssertionError();
            }
        }
        return new JSONArray().put(returnObject);
    }
}
