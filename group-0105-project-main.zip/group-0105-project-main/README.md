# Programming 3 assignment

Student Number: 2306808

## Introduction

This repository contains the template Java project for the Programming 3 assignment.
The assignment should be implemented in the [src/main/java/com/o3/server](src/main/java/com/o3/server) subfolder.
Any additional tests can be implemented in the [src/main/java/com/o3/server](src/test/java/com/o3/server) subfolder.
The [pom.xml](pom.xml) file contains the necessary dependencies for the assignment.
New dependencies will be added to the [pom.xml](pom.xml) file during the course.

## COMPLETED FEATURES

Features implemented:

    Feature 5: Contact FMI mock service to get observation location weather information
    Feature 6: Basic search functionality for observations
    Extra Feature 9: Give a summary of payload contents in description

